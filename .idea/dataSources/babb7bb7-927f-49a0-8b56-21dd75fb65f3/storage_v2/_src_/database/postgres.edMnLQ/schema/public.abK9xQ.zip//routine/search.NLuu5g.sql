create function search(name character varying)
    returns TABLE(username character varying, number character varying)
    language plpgsql
as
$$
begin
    return query
        select * from phonebook where phonebook.username like '%' ||name||  '%' order by name desc;
end
$$;

alter function search(varchar) owner to postgres;

