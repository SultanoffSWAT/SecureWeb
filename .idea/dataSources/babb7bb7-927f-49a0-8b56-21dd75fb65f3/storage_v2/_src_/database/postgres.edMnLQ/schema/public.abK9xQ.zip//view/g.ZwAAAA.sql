create view g(city, cities, locations) as
SELECT c.city,
       sum(s.amount * (d.commission + 1::double precision)) AS cities,
       sum(s.amount)                                        AS locations
FROM client c
         JOIN sell s ON c.id = s.client_id
         JOIN dealer d ON s.dealer_id = d.id AND c.city::text = d.location::text
GROUP BY c.city;

alter table g
    owner to postgres;

