create view c(dealer, number, average, total) as
SELECT dealer.*::dealer AS dealer,
       count(s.amount)  AS number,
       avg(s.amount)    AS average,
       sum(s.amount)    AS total
FROM sell s
         JOIN dealer ON s.dealer_id = dealer.id
GROUP BY dealer.*;

alter table c
    owner to postgres;

