create function getabovegpa(_gpa numeric)
    returns TABLE(id integer, name character varying, gpa numeric)
    language plpgsql
as
$$
begin
    return query
        select s.id, s.name, s.gpa
        from students as s
        where s.gpa >= $1;
end
$$;

alter function getabovegpa(numeric) owner to postgres;

