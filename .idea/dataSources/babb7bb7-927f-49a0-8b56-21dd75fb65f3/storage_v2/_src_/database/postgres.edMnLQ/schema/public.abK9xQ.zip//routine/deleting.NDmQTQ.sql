create procedure deleting(IN name character varying)
    language plpgsql
as
$$
begin
    delete from phonebook where username = $1;
end;
$$;

alter procedure deleting(varchar) owner to postgres;

