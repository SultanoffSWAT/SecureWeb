create function getstudent(_id integer) returns record
    language plpgsql
as
$$
declare
    student record;
begin
    select * into student from students where id = $1;
    return student;
end;
$$;

alter function getstudent(integer) owner to postgres;

