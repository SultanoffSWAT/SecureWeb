create function searcher()
    returns TABLE(username character varying, number character varying)
    language plpgsql
as
$$
begin
    return query
        select phonebook.username,phonebook.number
        from phonebook where phonebook.username like 'A%';
end
$$;

alter function searcher() owner to postgres;

