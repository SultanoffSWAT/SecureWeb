create procedure addstudent(IN id integer, IN name character varying, IN gpa numeric)
    language plpgsql
as
$$
begin
    insert into students(id, name, gpa) values ($1, $2, $3);
end;
$$;

alter procedure addstudent(integer, varchar, numeric) owner to postgres;

