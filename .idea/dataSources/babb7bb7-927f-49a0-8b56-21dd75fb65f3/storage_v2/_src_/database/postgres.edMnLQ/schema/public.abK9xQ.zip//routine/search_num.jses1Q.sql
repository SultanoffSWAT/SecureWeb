create function search_num()
    returns TABLE(username character varying, number character varying)
    language plpgsql
as
$$
begin
    return query
        select phonebook.username,phonebook.number
        from phonebook where phonebook.number like '8707%';

end
$$;

alter function search_num() owner to postgres;

