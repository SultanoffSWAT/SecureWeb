create procedure hello_world()
    language plpgsql
as
$$
begin
    raise notice 'hello world!';
end;
$$;

alter procedure hello_world() owner to postgres;

