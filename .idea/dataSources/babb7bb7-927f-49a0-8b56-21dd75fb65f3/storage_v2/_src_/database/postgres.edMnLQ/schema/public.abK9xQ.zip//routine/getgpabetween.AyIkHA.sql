create function getgpabetween(_gpa1 numeric, _gpa2 numeric)
    returns TABLE(id integer, name character varying, gpa numeric)
    language plpgsql
as
$$
begin
    return query
        select s.id, s.name, s.gpa
        from students as s
        where s.gpa between $1 and $2;
end
$$;

alter function getgpabetween(numeric, numeric) owner to postgres;

