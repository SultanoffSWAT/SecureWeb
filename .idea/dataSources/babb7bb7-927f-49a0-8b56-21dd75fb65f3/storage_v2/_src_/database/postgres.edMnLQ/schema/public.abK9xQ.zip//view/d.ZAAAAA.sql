create view d(dealer, earned) as
SELECT dealer.*::dealer                  AS dealer,
       sum(s.amount * dealer.commission) AS earned
FROM sell s
         JOIN dealer ON s.dealer_id = dealer.id
GROUP BY dealer.*;

alter table d
    owner to postgres;

