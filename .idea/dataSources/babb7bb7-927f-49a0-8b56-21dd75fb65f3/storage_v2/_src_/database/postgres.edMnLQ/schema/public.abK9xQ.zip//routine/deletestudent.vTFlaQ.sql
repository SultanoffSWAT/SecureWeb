create procedure deletestudent(IN id integer)
    language plpgsql
as
$$
begin
    delete
    from students s
    where s.id = $1;
end;
$$;

alter procedure deletestudent(integer) owner to postgres;

