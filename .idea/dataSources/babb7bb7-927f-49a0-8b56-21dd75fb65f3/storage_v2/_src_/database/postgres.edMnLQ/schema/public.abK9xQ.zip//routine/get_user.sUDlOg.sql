create function get_user(_username character varying, _number character varying) returns record
    language plpgsql
as
$$
declare
    phone record;
begin
    select * into phone from phonebook where username = $1;
    return phone;
end;
$$;

alter function get_user(varchar, varchar) owner to postgres;

