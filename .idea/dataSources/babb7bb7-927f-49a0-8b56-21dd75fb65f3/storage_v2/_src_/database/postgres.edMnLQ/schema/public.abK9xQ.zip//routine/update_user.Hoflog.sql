create procedure update_user(IN username character varying, IN number character varying)
    language plpgsql
as
$$
begin
    update phonebook
    set number = $2
    where phonebook.username = $1;
end;
$$;

alter procedure update_user(varchar, varchar) owner to postgres;

