create function getstudentname(_id integer) returns character varying
    language plpgsql
as
$$
declare
    student_name varchar;
begin
    select name into student_name from students where id = $1;
    return student_name;
end;
$$;

alter function getstudentname(integer) owner to postgres;

