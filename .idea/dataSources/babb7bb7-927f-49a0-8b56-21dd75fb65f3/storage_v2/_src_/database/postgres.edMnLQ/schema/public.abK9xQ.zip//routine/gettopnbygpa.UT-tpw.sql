create function gettopnbygpa()
    returns TABLE(id integer, name character varying, gpa numeric)
    language plpgsql
as
$$
begin
    return query
        select s.id, s.name, s.gpa
        from students as s
        order by s.gpa desc
        limit 5;
end
$$;

alter function gettopnbygpa() owner to postgres;

