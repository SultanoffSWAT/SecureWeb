create procedure add_user(IN username character varying, IN number character varying)
    language plpgsql
as
$$
begin
    insert into phonebook(username, number) values ($1, $2);
end;
$$;

alter procedure add_user(varchar, varchar) owner to postgres;

