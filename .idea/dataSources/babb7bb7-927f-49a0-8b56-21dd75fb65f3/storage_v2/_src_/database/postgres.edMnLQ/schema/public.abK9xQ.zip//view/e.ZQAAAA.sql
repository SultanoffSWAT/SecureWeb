create view e(location, number, average, total) as
SELECT dealer.location,
       count(s.amount) AS number,
       avg(s.amount)   AS average,
       sum(s.amount)   AS total
FROM dealer
         JOIN sell s ON dealer.id = s.dealer_id
GROUP BY dealer.location;

alter table e
    owner to postgres;

