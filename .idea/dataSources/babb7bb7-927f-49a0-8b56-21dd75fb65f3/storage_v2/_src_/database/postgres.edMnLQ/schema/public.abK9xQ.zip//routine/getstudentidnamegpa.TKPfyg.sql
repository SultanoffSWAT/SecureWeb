create function getstudentidnamegpa()
    returns TABLE(id integer, name character varying, gpa numeric)
    language plpgsql
as
$$
begin
    return query
        select s.id, s.name, s.gpa from students as s;
end
$$;

alter function getstudentidnamegpa() owner to postgres;

