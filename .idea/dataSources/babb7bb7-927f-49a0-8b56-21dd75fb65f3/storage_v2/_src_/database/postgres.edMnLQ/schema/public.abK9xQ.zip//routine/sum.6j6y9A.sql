create function sum(num1 integer, num2 integer) returns integer
    language plpgsql
as
$$
declare
    res integer;
begin
    res := $1 + $2;
    return res;
end
$$;

alter function sum(integer, integer) owner to postgres;

