create view f(city, number, average, total) as
SELECT c.city,
       count(s.amount)                                      AS number,
       avg(s.amount * (d.commission + 1::double precision)) AS average,
       sum(s.amount * (d.commission + 1::double precision)) AS total
FROM client c
         JOIN dealer d ON c.dealer_id = d.id
         JOIN sell s ON c.id = s.client_id
GROUP BY c.city;

alter table f
    owner to postgres;

