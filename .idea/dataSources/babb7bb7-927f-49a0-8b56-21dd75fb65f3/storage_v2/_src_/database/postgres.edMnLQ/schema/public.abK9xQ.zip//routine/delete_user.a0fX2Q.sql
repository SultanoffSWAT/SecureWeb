create procedure delete_user(IN username character varying)
    language plpgsql
as
$$
begin
    delete
    from phonebook s
    where s.username = $1;
end;
$$;

alter procedure delete_user(varchar) owner to postgres;

