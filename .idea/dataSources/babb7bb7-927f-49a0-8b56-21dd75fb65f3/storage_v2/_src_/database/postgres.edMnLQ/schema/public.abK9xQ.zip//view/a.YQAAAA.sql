create view a(date, number, average, total) as
SELECT sell.date,
       count(DISTINCT sell.client_id) AS number,
       avg(sell.amount)               AS average,
       sum(sell.amount)               AS total
FROM sell
GROUP BY sell.date;

alter table a
    owner to postgres;

