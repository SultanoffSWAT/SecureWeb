create function records(name character varying) returns record
    language plpgsql
as
$$
declare
    student record;
begin
    select * into student from phonebook where phonebook.username = $1;
    return student;
end;
$$;

alter function records(varchar) owner to postgres;

