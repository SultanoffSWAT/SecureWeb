create function get_offset(num integer)
    returns TABLE(username character varying, number character varying)
    language plpgsql
as
$$
begin
    return query
        select * from phonebook offset num;

end
$$;

alter function get_offset(integer) owner to postgres;

