create function inc(num integer) returns integer
    language plpgsql
as
$$
begin
    return num + 1;
end
$$;

alter function inc(integer) owner to postgres;

