create function get_user(_username character varying) returns record
    language plpgsql
as
$$
declare
    username record;
begin
    select * into username from phonebook where phonebook.username = $1;
    return username;
end;
$$;

alter function get_user(varchar) owner to postgres;

