create function get_limit(num integer)
    returns TABLE(username character varying, number character varying)
    language plpgsql
as
$$
begin
    return query
        select * from phonebook limit num;

end
$$;

alter function get_limit(integer) owner to postgres;

