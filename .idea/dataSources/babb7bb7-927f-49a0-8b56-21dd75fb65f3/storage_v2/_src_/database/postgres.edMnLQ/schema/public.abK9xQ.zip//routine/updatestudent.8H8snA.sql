create procedure updatestudent(IN id integer, IN name character varying)
    language plpgsql
as
$$
begin
    update students
    set name = $2
    where students.id = $1;
end;
$$;

alter procedure updatestudent(integer, varchar) owner to postgres;

