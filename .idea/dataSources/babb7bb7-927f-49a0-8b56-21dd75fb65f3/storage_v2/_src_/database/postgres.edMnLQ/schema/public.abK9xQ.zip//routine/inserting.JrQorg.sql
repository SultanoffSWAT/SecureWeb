create procedure inserting(IN n_name character varying, IN n_number character varying)
    language plpgsql
as
$$
BEGIN
    IF EXISTS (select * from phonebook where username = n_name) THEN
        UPDATE phonebook SET number = n_number where username = n_name;
    ELSE
        INSERT INTO phonebook Values (n_name, n_number);
END IF;
END;
$$;

alter procedure inserting(varchar, varchar) owner to postgres;

