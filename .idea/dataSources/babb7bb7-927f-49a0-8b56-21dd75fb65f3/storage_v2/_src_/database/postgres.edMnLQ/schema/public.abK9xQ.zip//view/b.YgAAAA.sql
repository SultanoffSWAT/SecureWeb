create view b(date, amount) as
SELECT DISTINCT sell.date,
                sell.amount
FROM sell
ORDER BY sell.amount DESC
LIMIT 5;

alter table b
    owner to postgres;

